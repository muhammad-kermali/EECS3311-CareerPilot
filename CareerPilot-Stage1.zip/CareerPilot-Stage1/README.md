# CareerPilot - Stage 1

Use **CareerPilot-Stage1-Short.pdf**. This 20-page version replaces the earlier reports.

## Contents
- PDF: complete design report.
- Markdown: editable report text with diagram previews.
- diagrams/: PlantUML sources and PNG previews. Shared-Entry.puml shows the common request/return flow printed in Section 5. Sequence sources SD01-SD08 show service interactions; some share a page in the PDF.
- Feature-Traceability.csv: full feature mapping table.
- build_report.py, feature-data.json, sequence-data.json and use-cases.png: report generation files. The script requires Python, ReportLab and PyMuPDF. It writes the PDF and text Markdown. Re-export diagram PNGs after rebuilding. Markdown edits do not automatically update the PDF.

## Submission
Upload the PDF and supporting files to the public EECS3311 project repository, then submit its URL through the course submission system. Extract this archive before uploading so the report is directly accessible. No working application is required for this design stage.

The report describes a proposed Java application and includes an AI-assistance statement.
